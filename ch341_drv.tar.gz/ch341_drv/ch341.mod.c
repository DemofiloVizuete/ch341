#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
};

static const struct modversion_info ____versions[]
__attribute_used__
__attribute__((section("__versions"))) = {
	{ 0x2b243a8e, "struct_module" },
	{ 0xcd6905f8, "usb_serial_disconnect" },
	{ 0x6b657bbc, "usb_serial_probe" },
	{ 0x5611e4ec, "param_get_bool" },
	{ 0xdc76cbcb, "param_set_bool" },
	{ 0xc3c86a73, "usb_serial_generic_open" },
	{ 0x35797b7b, "usb_register_driver" },
	{ 0x43eba4a4, "usb_serial_register" },
	{ 0xf9076936, "kmem_cache_zalloc" },
	{ 0x37a0cba, "kfree" },
	{ 0x426ae467, "kmem_cache_alloc" },
	{ 0x458a03ff, "malloc_sizes" },
	{ 0xa005c1d, "tty_get_baud_rate" },
	{ 0x40d2e1b0, "usb_control_msg" },
	{ 0x1b7d4074, "printk" },
	{ 0xc8c45355, "usb_serial_deregister" },
	{ 0x81a621ae, "usb_deregister" },
};

static const char __module_depends[]
__attribute_used__
__attribute__((section(".modinfo"))) =
"depends=usbserial";

MODULE_ALIAS("usb:v4348p5523d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v1A86p7523d*dc*dsc*dp*ic*isc*ip*");

MODULE_INFO(srcversion, "4AC2FABEFF7DEA21F488E6A");
