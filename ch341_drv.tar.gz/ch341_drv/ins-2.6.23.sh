#!/bin/bash
make -f Makefile-2.6.23
modprobe usbserial
insmod ch341.ko
