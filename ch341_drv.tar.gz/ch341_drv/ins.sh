#!/bin/bash
make
modprobe usbserial
insmod tty_ioctl.ko
insmod ch341.ko
